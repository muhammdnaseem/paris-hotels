// InputField.js
import React from 'react';
import '../css/inputfield.css';



export const Slider1Image1 = ({  }) => {
  return (
    <React.Fragment>
      <img src="https://photos.mandarinoriental.com/is/image/MandarinOriental/paris-suite-cabochons-suite-terrace-4?wid=1280&fmt=jpeg&op_usm=1,1,5,0&resMode=sharp2&fit=crop&qlt=75,0" />
    </React.Fragment>
  );
};


